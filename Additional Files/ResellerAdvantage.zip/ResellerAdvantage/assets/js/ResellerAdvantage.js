 /**
 * Reseller Advantage Widgets
 *
 * @package    ResellerAdvantage
 * @author     Terrence Harvey-Franklin <dev@eatmycode.io>
 * @copyright  2017 InMotion Hosting, Inc.
 * @license    TBD
 **/

function register(domain)
{
    var selected = 0,
        subtotal = 0.0;

    jQuery("#dotcom-results > div > div > span > input").each(function(i)
    {
        if(this.checked == true)
        {
            selected ++;
            subtotal += parseFloat(jQuery(this).attr('price'));
        }
    });

    if(selected > 0)
    {
        jQuery("#buy").css('display', 'block');
        jQuery("#buy").val('Order Selected Domains ($'+parseFloat(subtotal).toFixed(2)+')');
        jQuery("html, body").animate({
            scrollTop: jQuery("#dotcom-form").offset().top
        }, 1000);
    }
    else
    {
        jQuery("#buy").css('display', 'none');
        jQuery("#buy").val('Order Selected Domains');
    }
}

jQuery(document).ready(function()
{
    var loading, results;
    jQuery("form[id='dotcom-search']").on("submit", function()
    {
        var form = this;
        if(jQuery("input[name='dom']", form).val() == "")
        {
            var display = '<b>Please enter your desired domain!</b>';
            jQuery("div[id='loading']", form).css('display', 'none');
            jQuery("div[id='dotcom-results']").css('display', 'block');
            jQuery("div[id='dotcom-results']").html(unescape(display));
            //alert('Please enter your desired domain!');
            return false;
        }

        var domain = jQuery("input[name='dom']", form).val();
        jQuery("div[id='dotcom-results']").html('&nbsp;');
        jQuery("div[id='dotcom-results']").css('display', 'none');
        jQuery("div[id='loading']", form).css('display', 'inline');

        var data = {
            'action': 'reseller_adv_domain_search_display',
            'dom': domain,
            'security' : reseller_adv_ajax.reseller_adv_nonce
        };

        var jqxhr = jQuery.post(reseller_adv_ajax.ajaxurl, data, function(response)
        {
            var display = '',
                result = response;

            for(whois in result)
            {
                if(result[whois].status == 1)
                {
                    display += result[whois].text+'<br />';
                    link = '';
                }
                else if(result[whois].status == 0)
                {
                    display += result[whois].text+'<br />';
                }
                else if(result[whois].status == 2)
                {
                    display = "Ooops... an error occured!";
                    jQuery("div[id='results']").html(unescape(display));
                    break;
                }

                if(whois == 0)
                {
                    display += "<p class='additional-domains'><b>We looked at a few others just in case...</b></p><br />";
                }
            }

            jQuery("div[id='loading']", form).css('display', 'none');
            jQuery("div[id='dotcom-results']").css('display', 'block');
            jQuery("div[id='dotcom-results']").html(unescape(display));

        }, "json").fail(function()
        {
            var display = "<b>Woah... Something is broken!<b/><br />Please check your settings.";
            jQuery("div[id='loading']", form).css('display', 'none');
            jQuery("div[id='dotcom-results']").css('display', 'block');
            jQuery("div[id='dotcom-results']").html(unescape(display));
        });

        return false;
    });

    jQuery("form[id='dotcom-register']").on("submit", function()
    {
        var bridge = reseller_adv_ajax.whmcs_bridge;
        jQuery("#dotcom-results > div > div > span > input").each(function(i)
        {
            if(this.checked == true)
            {
                bridge += '&domains[]='+this.id
            }
        });

        location.href = bridge;
        return false;
    });
});

// EOF
