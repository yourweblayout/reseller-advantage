<?php
/**
 * Plugin Name: Reseller Advantage
 * Description: WP & WHMCS Synergy
 * Version: 1.1
 * Author: Terrence Harvey-Franklin <dev@eatmycode.io>
 * Author URI: http://eatmycode.io/
 * Text Domain: reseller
 *
 * @package    ResellerAdvantage
 * @author     Terrence Harvey-Franklin <dev@eatmycode.io>
 * @copyright  2017 InMotion Hosting, Inc.
 * @license    TBD
 **/

/**
 * Loads required scripts and stylesheets into WP environment.
 *
 * @return  void
 *
 * @since   1.0.4 Added whmcs_bridge url to localizer
 * @since   1.0.0
 */
function reseller_adv_setup()
{
    // Fetch user settings
    $config = get_option('reseller_adv_setting');

    // Add CSS
    wp_enqueue_style(
        'reseller-adv-styles',
        plugins_url('assets/css/ResellerAdvantage.css', __FILE__)
    );

    // Add JS
    wp_enqueue_script(
        'reseller-adv-script',
        plugins_url('assets/js/ResellerAdvantage.js', __FILE__),
        array('jquery')
    );

    // Making some data available here to js that we can
    // normally only get from the server side
    wp_localize_script(
        'reseller-adv-script',
        'reseller_adv_ajax',
        array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'reseller_adv_nonce' => wp_create_nonce('reseller_adv_nonce'),
            'whmcs_bridge' => preg_replace(
                '/\/$/', '', $config['reseller_adv_whmcs_location']
            ).'/cart.php?a=add&domain=register'
        )
    );
}

/**
 * Enqueue both, scripts and styles from a single action hook.
 *
 * @link https://developer.wordpress.org/reference/functions/wp_enqueue_script/#comment-274
 *
 * @since   1.0.0
 */
add_action('wp_enqueue_scripts', 'reseller_adv_setup');
add_action('admin_enqueue_scripts', 'reseller_adv_setup');

/**
 * Creates plugin settings
 *
 * @since   1.0.4
 */
include('ResellerAdvantage.conf');

if(is_admin())
{
    $config = new ResellerAdvantage();
}

/**
 * Sets default plugin options on activation
 *
 * @since   1.0.7
 */
register_activation_hook(__FILE__, array($config, 'reseller_adv_activation_actions'));
register_deactivation_hook(__FILE__, array($config, 'reseller_adv_deactivation_actions'));

add_action('wp_reseller_adv_extension_activation', array($config, 'reseller_adv_default_options'));

/**
 * Loads plugin widgets
 *
 * @since   1.0.5 Source all widgets @link https://developer.wordpress.org/reference/functions/plugin_dir_path/#comment-492
 * @since   1.0.4
 */
foreach(glob(plugin_dir_path(__FILE__)."widgets/*.php") as $widget)
{
    include_once $widget;
}

/**
 * Configures automatic updates
 *
 * @since   1.0.8
 */
require 'lib/AutoUpdate.php';

$config = get_option('reseller_adv_setting');
$update = Puc_v4_Factory::buildUpdateChecker(
    $config['source'],
    __FILE__,
    'reseller_adv'
);

$update->declareCredentials(array(
  'license_key' => __('License Key:'),
));

// EOF
