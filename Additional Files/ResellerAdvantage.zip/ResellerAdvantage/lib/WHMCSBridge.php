<?php
/**
 * WHMCSBridge
 *  └── PHP Class responsible for handling WHMCS API calls.
 *
 * @package    ResellerAdvantage\lib\WHMCSBridge
 * @author     Terrence Harvey-Franklin <dev@eatmycode.io>
 * @copyright  2017 InMotion Hosting, Inc.
 * @license    TBD
 * @version    1.0.0
 *
 * @todo       Update docblocks
 **/
class WHMCSBridge
{
    private $accesskey = null;
    private $usr       = null;
    private $pwd       = null;
    private $url       = null;

    private $_result = null;
    private $_info   = null;

    /**
     * Constructor
     * @since   1.0.0
     * @access  public
     * @param   array
     */
    public function __construct($auth=array(), $init=false)
    {
        if (isset($auth['usr']) && isset($auth['pwd']) && isset($auth['url']))
        {
            $init = true;
        }

        foreach(array('usr', 'pwd', 'url') as $key)
        {
            if($key == 'pwd' && isset($auth[$key]))
            {
                $auth[$key] = md5($auth[$key]);
            }
            if(isset($auth[$key]))
            {
                $this->$key = $auth[$key];
            }
        }

        if(!$init)
        {
            die();
        }
    }


    /**
     * Magic call method
     *
     * @access      public
     * @param       string
     * @param       array
     *
     * @return      array | false
     * @since       1.0.0
     */
    public function __call($name, $args)
    {
        if(in_array($name, array('setUsr', 'setPwd', 'setUrl', 'setAccesskey')))
        {
            return $this->setitem($name, $args);
        }

        $data = (count($args) > 0 ? array_shift($args) : array());

        if(!is_array($data))
        {
            //Data passed to WHMCS API is not an array
            //array('notanarray' => $data);
            $data = array($data);
        }

        if(!isset($data['responsetype']))
        {
            $data['responsetype'] = 'json';
        }
        $this->responsetype = $data['responsetype'];

        $response = $this->_request($name, $data);

        if(!is_array($response))
        {
            $res = array( 'response' => $response );
        }
        else
        {
            $res = $response;
        }

        return $response;
    }

    /**
     * Method to set an item on this object
     *
     * @access      public
     * @version     @fileVers@
     * @param       string      method called
     * @param       array       passed by magic __call method
     *
     * @since       1.0.0
     */
    public function setitem($name, $args)
    {
        $name = strtolower(str_replace('set', '', $name));
        $value = $args[0];

        if($name == 'pwd')
        {
            $value = md5($value);
        }

        $this->$name = $value;
    }

    /**
     * Method for parsing all returned data regardless of response type
     *
     * @desc        Provide uniform method of retrieving data from our system
     * @access      private
     * @param       string
     * @param       string
     *
     * @return      array | string | false
     * @since       1.0.0
     */
    private function _parse($data, $action=null)
    {
        switch($this->responsetype):

            case 'xml':
                libxml_use_internal_errors(true);
                $xml = simplexml_load_string($data);
                if($xml === false)
                {
                    //foreach(libxml_get_errors() as $error)
                    //{
                        //XML Parsing Error!
                        //$error->message
                        //array('data' => $data)
                    //}
                    return false;
                }

                $result = json_decode(json_encode($xml));
                break;

            case 'json':
                $result = json_decode(trim($data));
                break;

            case 'nvp':
                $result = array();
                $parts = explode("&", trim($data, "\""));
                foreach($parts as $piece ) {
                    $tmp = explode("=", $piece);
                    $result[$tmp[0]] = $tmp[1];
                }
                break;

        endswitch;

        return $result;
    }


    /**
     * Method to make a request to the WHMCS API
     *
     * @access      private
     * @param       string
     * @param       array
     *
     * @return      mixed|false
     * @since       1.0.0
     */
    private function _request($action, $fields)
    {
        $fields['username'] = $this->usr;
        $fields['password'] = $this->pwd;

        if(!is_null($this->accesskey))
        {
            $fields['accesskey'] = $this->accesskey;
        }

        $fields['action'] = $action;

        $call = rtrim($this->url, '/' ).'/includes/api.php';

        try
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $call);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 300);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));

            $file = curl_exec($ch);
            if(curl_error($ch))
            {
                throw new \Exception('Unable to connect: '.curl_errno($ch).' - '.curl_error($ch));
            }

            $this->_result = $file;
            $this->_info   = curl_getinfo($ch);
            curl_close($ch);
        }
        catch (\Exception $e)
        {
            $arr = array(
                'message' => $e->getMessage(),
                'call'    => $call,
                'result'  => $file,
            );
            foreach($fields as $k => $f)
            {
                $arr["{$k}"] = $f;
            }

            //Error making call to API:
            //$action
            //array($arr);
            return false;
        }

        $results = $this->_parse($file, $action);
        return $results;
    }
}

// EOF
