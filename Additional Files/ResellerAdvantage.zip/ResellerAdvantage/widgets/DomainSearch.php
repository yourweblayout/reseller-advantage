<?php
 /**
 * Reseller Advantage Widget
 *  └── Domain Search
 *
 * @package    ResellerAdvantage
 * @author     Terrence Harvey-Franklin <dev@eatmycode.io>
 * @copyright  2017 InMotion Hosting, Inc.
 * @license    TBD
 **/

/**
 * Handles the domain WHOIS lookup
 *
 * @return  void
 *
 * @since   1.0.0
 */
function reseller_adv_domain_search_func()
{
    // Verifies the Ajax request to prevent processing requests external of the site
    check_ajax_referer('reseller_adv_nonce', 'security');

    // Location of helper classes
    $resource = plugin_dir_path(__FILE__).'../lib/';

    if(isset($_POST['dom']))
    {
        /**
         * Strip leading dub dub dub and/or protocol (if any)
         *
         * @todo Catch any additional false positives here; or add validation
         *
         * @since   1.0.0
         */
        $domain = str_replace(array('www.', 'http://', 'https://'), NULL, $_POST['dom']);

        // Check if a TLD/ccTLD was provided)
        $parts = explode('.', $domain);
        if(count($parts) == 1)
        {
            // No TLD/ccTLD was provided so default to ".com"
            $domain = $domain.".com";
        }

        // Strip any disallowed characters from entry
        $domain = preg_replace("/[^-a-zA-Z0-9.]+/", "", $domain);

        // Check domain availability
        if(strlen($domain) > 0)
        {
            // Fetch user settings
            $config = get_option('reseller_adv_setting');

            /**
             * Init WHMCS API
             *
             * @todo Test bridge
             *
            include ($resource.'/WHMCSBridge.php')
            $reseller_api = new WHMCSBridge();

            $reseller_api->setUsr($config['reseller_adv_whmcs_user');
            $reseller_api->setPwd($config['reseller_adv_whmcs_passwd']);
            $reseller_api->setUrl($config['reseller_adv_whmcs_location']);
            //*/

            // Fetch WHMCS MySQL configuration details
            $whmcs_conifg = file($_SERVER['DOCUMENT_ROOT'].'/'.$config['reseller_adv_whmcs_working_dir'].'/configuration.php');
            foreach(array('db_host', 'db_username', 'db_password', 'db_name') as $key => $setting)
            {
                foreach($whmcs_conifg as $val)
                {
                    if($val != null && preg_match('/'.$setting.'/', $val))
                    {
                        $whmcsql[$key] = explode("'", $val)[1];
                    }
                }
            }

            // Open connection to WHMCS database
            if(!($db = mysql_connect($whmcsql[0], $whmcsql[1], $whmcsql[2], true)))
            {
                die('Could not connect to WHMCS Host: '.mysql_error($db));
            }
            else
            {
                if(!mysql_select_db($whmcsql[3], $db))
                {
                    die('Could not find WHMCS Database: '.mysql_error($db));
                }
            }

            // Fetch "allowed" TLDs/ccTLDs from WHMCS
            // These TLDs/ccTLDs have been setup as being able to be registered
            $query = "
                SELECT extension AS tld, msetupfee AS price
                FROM tbldomainpricing AS tld
                LEFT JOIN tblpricing AS price ON price.relid = tld.id
                WHERE type = 'domainregister'
            ";

            $tlds = mysql_query($query, $db);

            if(mysql_errno($db) > 0)
            {
                die('Could not fetch TLD/ccTLD pricing: '.mysql_error($db));
            }

            // Limit "additional checks" to first 6 options.
            $counter = 0;
            $limit = 6;
            while($result = mysql_fetch_assoc($tlds))
            {
                if($counter == $limit)
                {
                    break;
                }

                foreach($result as $key => $val)
                {
                    $allowed_tlds[preg_replace('/^\./', '', $result['tld'])] = $result['price'];
                }

                $counter++;
            }

            /**
             * Check domain availability and registrability against $allowed_tlds
             *
             * @todo Implement some sort of paging or max limit on "additional results"
             *
             * @since   1.0.0
             */
            include($resource.'DomainAvailability.php');
            $check = new DomainAvailability();

            $result = $check->is_available($domain, $allowed_tlds);

            // Parse and format results
            foreach($result as $domain => $status)
            {
                $custom_found_result_text     = __('✔ <b>'.$domain.'</b> is available!', 'reseller');
                $custom_not_found_result_text = __('Ooops... <b>'.$domain.'</b> is already taken!', 'reseller');

                // Get pricing
                $tld = explode('.', $domain);
                unset($tld[0]);
                $tld = implode('.', $tld);
                $price = $allowed_tlds[$tld];

                if($status == '1')
                {
                    // Domain is available to be registered
                    $result[] = array(
                        'status' => 1,
                        'domain' => $domain,
                        'text'   => '<div style="position:relative;width:100%"><div class="available"><span class="pull-left">'.$custom_found_result_text.'</span><span class="pull-right" style="margin-top:0"> &nbsp; Order</span><span class="pull-right" style="margin-top:-2px"> &nbsp;&nbsp;&nbsp; <input type="checkbox" name="'.$domain.'" id="'.$domain.'" onchange="register(this);" price="'.$price.'" /></span></div><div class="pricing"><b>$'.$price.'</b></div></div>'
                    );
                }
                elseif($status == '0')
                {
                    // Domain is NOT available to be registered
                    $result[] = array(
                        'status' => 0,
                        'domain' => $domain,
                        'text'   => '<p class="not-available">'.$custom_not_found_result_text.'</p>'
                    );
                }
                elseif($status == '3')
                {
                    // Domain has NOT been enabled for registrations via WHMCS
                    $result[] = array(
                        'status' => 0,
                        'domain' => $domain,
                        'text'   => '<p class="not-available">Sorry... "<b>.'.$tld.'</b>" domains are not yet supported.</p>'
                    );
                }
                else
                {
                    // Domain lookup failed
                    $result[] = array(
                        'status' => 0,
                        'domain' => $domain,
                        'text'   => '<p class="not-available">Uh-oh... WHOIS server not found for that TLD</p>'
                    );
                }
            }

            echo json_encode($result);
        }
        else
        {
            echo 'Please enter your desired domain!';
        }
    }
    die();
}

/**
 * Fires authenticated Ajax actions for BOTH logged-in and NOT logged-in users.
 *
 * @link https://developer.wordpress.org/reference/hooks/wp_ajax__requestaction/#comment-1764
 *
 * @since   1.0.0
 */
add_action('wp_ajax_reseller_adv_domain_search_display', 'reseller_adv_domain_search_func');
add_action('wp_ajax_nopriv_reseller_adv_domain_search_display', 'reseller_adv_domain_search_func');

/**
 * Use shortcode in Domain Search dashboard widget
 *
 * @return  void
 *
 * @since   1.0.0
 */
function reseller_adv_display_domain_search()
{
    do_shortcode('[resellerdomainsearch width="350"]');
}

/**
 * Adds a new dashboard widget
 *
 * @return  void
 *
 * @since   1.0.0
 */
function reseller_adv_add_dashboard_widgets()
{
    wp_add_dashboard_widget(
        'reseller_adv_domain_search_widget',
        'Domain Search',
        'reseller_adv_display_domain_search'
    );
}

/**
 * Register dashboard widgets
 *
 * @since   1.0.0
 */
add_action('wp_dashboard_setup', 'reseller_adv_add_dashboard_widgets');

/**
 * Displays Domain Search tool via shortcode
 *
 * @param   array $atts optional width and button text values can be explicitly defined
 *
 * @return  string $content HTML
 *
 * @since   1.0.6 Removed base64 loader and added CSS animation.
 * @since   1.0.0
 */
function reseller_adv_display_domain_search_shortcode($atts)
{
    // Merge attributes
    $atts = shortcode_atts(
        array(
            'width'  => '600',
            'button' => 'Find My Domain'
        ),
        $atts
    );

    // Build HTML
    $content = '
        <center>
            <div id="dotcom-form">
                <form method="post" action="./" id="dotcom-search" class="pure-form">
                    <input type="text" autocomplete="off" id="reseller-domainsearch" name="dom" class="reseller-domainsearch-input" style="width:100%;max-width:'.$atts['width'].'px;" placeholder="ie. whatsmyname.com">
                    <input type="submit" id="Submit" value="'.$atts['button'].'" class="pure-button button-blue reseller-domainsearch">
                    <p>
                        <div id="loading">
                            <div id="fountainG">
                                <div id="fountainG_1" class="fountainG"></div>
                                <div id="fountainG_2" class="fountainG"></div>
                                <div id="fountainG_3" class="fountainG"></div>
                                <div id="fountainG_4" class="fountainG"></div>
                                <div id="fountainG_5" class="fountainG"></div>
                                <div id="fountainG_6" class="fountainG"></div>
                                <div id="fountainG_7" class="fountainG"></div>
                                <div id="fountainG_8" class="fountainG"></div>
                            </div>
                        </div>
                    </p>
                </form>
                <form method="post" action="./" id="dotcom-register" class="pure-form">
                    <p><div id="dotcom-results" class="result"></div></p>
                    <input type="submit" id="buy" value="Order Selected Domains" class="pure-button button-blue reseller-domainsearch">
                </form>
            </div>
        </center>
    ';

    // Display Domain Search tool
    $validated = get_option('otup_credentials_validated_reseller_adv');
    if($validated)
        return $content;
    else
        return '<b style="color:#a00">This plugin is not authorized for use on this site!</b>';
}

/**
 * Register shortcodes
 *
 * @since   1.0.0
 */
add_shortcode('resellerdomainsearch', 'reseller_adv_display_domain_search_shortcode');

/**
 * PHP Class responsible for manipulation of Domain Search widget
 *
 * @param   string $name ... of our widget
 *
 * @return  void
 *
 * @since   1.0.0
 **/
class reseller_adv_domain_search_widget extends WP_Widget
{
    /**
     * Constructor
     *
     * @access      private
     * @param       boolean
     * @param       string
     *
     * @return      void
     *
     * @since       1.0.0
     */
    function __construct()
    {
        parent::__construct(false, $name=__('Domain Search Widget'));
    }

    /**
     * Builds HTML form for admin user to configure the widget
     *
     * @access      private
     * @param       array $instance
     *
     * @return      void
     *
     * @since       1.0.0
     */
    function form($instance)
    {
        // Set attributes (if any)
        if(isset($instance['title']))
        {
            $title  = $instance['title'];
            $width  = $instance['width'];
            $button = $instance['button'];
        }
        else
        {
            $title = "Domain Search";
        }

        // Build HTML
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','reseller'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
            </label>
        </p>
        <p>
        <label for="<?php echo $this->get_field_id('width'); ?>"><?php _e('Width:','reseller'); ?>
            <input class="widefat" id="<?php echo $this->get_field_id('width'); ?>" name="<?php echo $this->get_field_name('width'); ?>" type="text" value="<?php echo $width; ?>" />
        </label>
        </p>
        <p>
        <label for="<?php echo $this->get_field_id('button'); ?>"><?php _e('Button Name:','reseller'); ?>
            <input class="widefat" id="<?php echo $this->get_field_id('button'); ?>" name="<?php echo $this->get_field_name('button'); ?>" type="text" value="<?php echo $button; ?>" />
        </label>
        </p>
        <?php
    }

    /**
     * Updates widget attributes as defined by the admin user
     *
     * @access      private
     * @param       array $new_instance
     * @param       array $old_instance
     *
     * @return      array $instance
     *
     * @since       1.0.0
     */
    function update($new_instance, $old_instance)
    {
        $instance = array();

        $instance['title']  = (!empty($new_instance['title']))  ? strip_tags($new_instance['title'])  : '';
        $instance['width']  = (!empty($new_instance['width']))  ? strip_tags($new_instance['width'])  : '';
        $instance['button'] = (!empty($new_instance['button'])) ? strip_tags($new_instance['button']) : '';

        return $instance;
    }

    /**
     * Builds and displays the widget
     *
     * @access      private
     * @param       array $args
     * @param       array $instance
     *
     * @return      void
     *
     * @since       1.0.0
     */
    function widget($args, $instance)
    {
        $title  = ($instance['title']  != '') ? $instance['title']  : 'Domain Search';
        $width  = ($instance['width']  != '') ? $instance['width']  : '150';
        $button = ($instance['button'] != '') ? $instance['button'] : 'Search';

        echo $args['before_widget'];

        if($title)
        {
            echo $args['before_title'].$title.$args['after_title'];
        }

        echo do_shortcode("[resellerdomainsearch width='$width' button='$button']");
        echo $args['after_widget'];
    }
}

/**
 * Wrapper to register the Domain Search widget
 *
 * @return  void
 *
 * @since   1.0.0
 */
function register_reseller_adv_domain_search_widget()
{
    register_widget('reseller_adv_domain_search_widget');
}

/**
 * Register widget
 *
 * Fires after all default WordPress widgets have been registered.
 *
 * @since   1.0.0
 */
add_action('widgets_init', 'register_reseller_adv_domain_search_widget');

// EOF
